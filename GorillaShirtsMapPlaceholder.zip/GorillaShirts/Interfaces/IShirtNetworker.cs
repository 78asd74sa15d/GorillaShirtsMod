﻿namespace GorillaShirts.Interfaces
{
    public interface IShirtNetworker
    {
        void SetCustomProperties();
        void PushCustomProperties();
    }
}
