﻿namespace GorillaShirts.Models
{
    public enum ShirtAudio
    {
        WearShirt,
        RemoveShirt,
        ButtonPress,
        SillyYap,
        SteadyYap,
        DiceRoll,
        Error,
        Shutter,
        DrawerOpen,
        DrawerClose
    }
}
