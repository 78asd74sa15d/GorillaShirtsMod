﻿namespace GorillaShirts.Models
{
    public enum ButtonType
    {
        ShirtEquip, ShirtIncrease, ShirtDecrease, PackDecrease, PackIncrease,
        RigToggle, Randomize, TagIncrease, TagDecrease, Info, Capture
    }
}
