﻿namespace GorillaShirts.Models
{
    public enum SectorType
    {
        Body, Head, LeftUpper, LeftLower, LeftHand, RightUpper, RightLower, RightHand
    }
}
